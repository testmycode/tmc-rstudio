RetTrue <- function() {
  return(TRUE)
}

#This function produces an error
RetOne <- function() {
  error in source code
}

Add <- function(a, b) {
  return(a + b)
}