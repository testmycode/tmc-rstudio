ret_true <- function() {
  return(TRUE)
}

ret_one <- function() {
  return(1)
}

add <- function(a, b) {
  return(a + b)
}

ret_false <- function() {
  return(FALSE)
}
