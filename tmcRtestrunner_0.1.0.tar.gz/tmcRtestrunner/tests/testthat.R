library(testthat)
library(jsonlite)
library(tmcRtestrunner)

test_check("tmcRtestrunner")
