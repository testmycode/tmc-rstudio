#include <stdio.h>
#include "source.h"

void calculate(void) {

}
