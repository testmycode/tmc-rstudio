void calculate(void);
