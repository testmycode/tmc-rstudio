a <- 2
b <- 2
pow <- 2^2
print(paste0("pow: ", pow))
