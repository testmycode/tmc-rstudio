a <- 1
a
b <- 2
add <- a+b
add
mul <- a*b
mul