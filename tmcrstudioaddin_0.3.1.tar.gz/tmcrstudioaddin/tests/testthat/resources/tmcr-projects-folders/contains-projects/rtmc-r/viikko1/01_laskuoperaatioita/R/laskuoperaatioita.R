#6)
#a)
a <- 120 + 17^2

#b)
b <- 1:50

#c)
c <- sqrt(a)/b

#d)
d <- cos(exp(c))

#e)
e <- sum(d[d > 0])
