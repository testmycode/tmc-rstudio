library(testthat)
library(httptest)
library(tmcrstudioaddin)

test_check("tmcrstudioaddin")
