source("R/Authentication.R")

token <- authenticate(username = "usernameHere", password = "passwordHere")
course <- temp_get_course(token = token)
